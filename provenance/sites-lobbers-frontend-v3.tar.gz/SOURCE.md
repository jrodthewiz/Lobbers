# Lobbers private frontend GitHub sync

Current game source: https://github.com/jrodthewiz/Lobbers/tree/2f4c145ca10cc4a2f2c7f88795c8e1ed2ad3d9ad

Build with `VITE_STATIC_FRONTEND=true VITE_SERVER_URL= npm run build`; output is dist/client. Current runtime hashes, validation and limitations are in source-provenance/github-sync-20261113.json. Earlier provenance and asset files are retained for history but are not the current build.

Demolition and same-device duel are available. Online artillery and peer signaling are not configured; the UI explicitly says so. Preserve the existing private Site identity, audience, credits and origin saves. No D1/R2 data or server was changed. GitHub push alone does not update this Site; rebuild, package through the native source helper, save/deploy matching source+archive, and record the revision.
